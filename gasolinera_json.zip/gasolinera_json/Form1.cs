﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;


namespace gasolinera_json
{
    public partial class Form1 : Form
    {
        System.IO.Ports.SerialPort arduino;
        public Form1()
        { 
            InitializeComponent();
            Bitmap img = new Bitmap(Application.StartupPath + @"\jsn\sech.jpg");
            this.BackgroundImage = img;
            this.BackgroundImageLayout = ImageLayout.Stretch;


            arduino = new System.IO.Ports.SerialPort();
            arduino.PortName = "COM5";
            arduino.BaudRate = 9600;
            arduino.Open();
        }
        int cont = 0;
        int cont2 = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            
            var data = new { action = "E" };

            
            string jsonData = JsonConvert.SerializeObject(data);

            
            arduino.Write(jsonData); 

          

            
            timer1 = new Timer();
            timer1.Interval = 500; 
            timer1.Tick += timer1_Tick;

            
            timer1.Start();

            timer2 = new Timer();
            timer2.Interval = 16500;
            timer2.Tick += timer2_Tick;

          
            timer2.Start();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(arduino.IsOpen)
            {

                arduino.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            var data = new { action = "F" };

            
            string jsonData = JsonConvert.SerializeObject(data);

           
            arduino.Write(jsonData);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           int numero=int.Parse(textBox1.Text);
            if (cont < numero)
            {
               
                cont++;

              
                label1.Text = cont.ToString();
            }
            else
            {
                
                timer1.Stop();

                timer2.Stop();
                
            }
               
            if(cont == numero) {


                
                var data = new { action = "F" };

               
                string jsonData = JsonConvert.SerializeObject(data);

                
                arduino.Write(jsonData);
            }
            else { }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            cont = 0;

          
            textBox1.Text = "";

            
            label1.Text = "";
            label5.Text = "";
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            int numero2 = int.Parse(label1.Text);

            int gal = numero2 / 33;

            int litros = gal * 3;

          


            if ( cont2 < numero2)
            {
               
                cont2+=3;

            
                label5.Text = cont2.ToString();
            }
            else
            {
                
                timer2.Stop();


               

            
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
    }

